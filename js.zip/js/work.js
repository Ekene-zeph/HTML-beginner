    document.write('Hello world!');

    // loops 
    // for loop 
    for(i=0;i<10;i++){
        document.write(i);
        document.write('<br> Helo world')
    }

    colors = 'red,blue,yellow'
    cols = colors.split(',')
    document.write(cols)

    // ul.innerHTML = `<li> ${cols[0]}</li>`
    // ul.innerHTML += `<li> ${cols[1]}</li>`
    // ul.innerHTML += `<li> ${cols[2]}</li>`
    // ul.innerHTML += `<li> ${cols[3]}</li>`
    // ul.innerHTML += `<li> ${cols[4]}</li>`

    for(x=0;x<cols.length;x++){
        ul.innerHTML += `<li> ${cols[x]}</li>`
    }

    y = 2027;
    year = new Date().getFullYear();
    while(y<=year){
        yob.innerHTML += `<option> ${y}</option>`
        y++;
    }

    // Js dates 
    document.write(new Date().getFullYear())
    today = new Date();
    mins = today.getMinutes();
    secs = today.getSeconds();

    endyear = year-18
    startyear = year-25;

    for(x=startyear;x<=endyear;x++){
        document.write(`<li>${x}`);
    }
    // alphabets  = 
    // 0-9 = 10

    characters  = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    text = ''
    for(i=0;i<6;i++){
        // characters 
        n1 = Math.floor(Math.random()*61);
        text+=characters[n1];
    }
    document.write('<br>'+text)


    temp = 50;
    if(temp>30){
        document.write('<h3> Turn on AC</h3>')
    }else{
        document.write('<h3> Turn Off AC</h3>')
    }

    login = {
        user:'admin',
        pass:'1234'
    }

    db =` {
        user:'admin',
        pass:'1234'
    }`
    if(login.user == db.user && login.pass== db.pass){
        document.write('<h3>Login  Successfull</h3>')
    }else{
        document.write('<h3>Invalid Login Credentials </h3>')

    }


    let name = document.getElementById('user');