person = {
    name:"solomon",
    age: 25,
    details:function(){
        return "My name is "+person.name
    }
}
text.innerHTML = (document);
text.innerHTML += (person.name);
text.innerHTML = person.details()


//declare
function myFunction(){
    text.innerHTML = ('Yello world!');
}

// myFunction()

function myFunction1(a,b){
    text.innerHTML = a+b
}
myFunction1(12,6)
myFunction1(12,100)
myFunction1(12,10)
myFunction1(45,7)


function sum(x,y){
    return x+y
}
z = sum(12,5)
text.innerHTML = sum(23,6)

text.innerHTML = person.details()
fruits = [];

str = 'Yello World! welcome';
console.log(str.length)
str1 = 'yello'
str2 = 'World!'
console.log(str1+" "+str2)
console.log(str1.concat(' ',str2,' Welcome '))
console.log(`Welcome ${str1} ${str2} `)
newStr = str.slice(5);
console.log(newStr);
console.log(str.toUpperCase().indexOf('Y'));
console.log((Math.random()*9999).toFixed())
console.log(Math.ceil(Math.random()*9999))


// create a program that randomly chages the bg of a web page 

